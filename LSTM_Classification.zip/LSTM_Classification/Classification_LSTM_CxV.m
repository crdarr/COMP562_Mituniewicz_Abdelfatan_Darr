%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course:     COMP 562  
% Instructor: Dr. Jorge Silva
% Assignment: Final Project   
%   
% Author:           Caleb Ryan Darr - crd.darr@gmail.
% Collaborators:    Austin L. M.
% 
% Description: 
% Classifer for dangerous vs safe guage cycle ground reaction force time
% series using Long short-term memory (LSTM) network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc;
%% LOAD DATA

% Full time data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('fullFeats_long.csv'); % Snipped Raw Data to area of interest

% Snipped time data
data = readmatrix('backFeats_v3.csv')'; % Snipped Raw Data to area of interest
labels = readmatrix('labelFileBinary_v3.csv'); % Labels of binary data

% Time frequency Data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('data_ForceFreq.csv'); % Snipped Raw Data to area of interest

% Momentum Data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('data_momentum.csv'); % Snipped Raw Data to area of interest

%% Partition data for Cross - Validation: K-Folds
%Partition Labels
label_fold1 = labels(1:69);
label_fold2 = labels(70:138);
label_fold3 = labels(139:207);
label_fold4 = labels(208:276);
label_fold5 = labels(277:345);

%Partition Data
data_fold1 = data(:,1:69);
data_fold2 = data(:,70:138);
data_fold3 = data(:,139:207);
data_fold4 = data(:,208:276);
data_fold5 = data(:,277:345);

%% Number of Hidden Units
HiddenUnits = 5:5:100;
tic

%% Cross Validation
aa_model_num = 0;
for a =1:5 % Number of k-folds
    for b = HiddenUnits
        for c = 0.5:0.25:1.5
            for d = 15:5:35    %minibatch size
        % TRAINING VS TESTING Data
        aa_model_num = aa_model_num + 1;
        if a == 1
		%Testing Data
        XTest = mat2cell(data_fold1, 402, ones(1,69))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(label_fold1);

		%Training Data
        XTrain = mat2cell([data_fold2, data_fold3, data_fold4, data_fold5], 402, ones(1,276))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical([label_fold2; label_fold3; label_fold4; label_fold5]);

        elseif a == 2
		%Testing Data
        XTest = mat2cell(data_fold2, 402, ones(1,69))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(label_fold2);

		%Training Data
        XTrain = mat2cell([data_fold1, data_fold3, data_fold4, data_fold5], 402, ones(1,276))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical([label_fold1; label_fold3; label_fold4; label_fold5]);

        elseif a == 3
		%Testing Data
        XTest = mat2cell(data_fold3, 402, ones(1,69))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(label_fold3);

		%Training Data
        XTrain = mat2cell([data_fold1, data_fold2, data_fold4, data_fold5], 402, ones(1,276))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical([label_fold1; label_fold2; label_fold4; label_fold5]);

        elseif a == 4
		%Testing Data
        XTest = mat2cell(data_fold4, 402, ones(1,69))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(label_fold4);

		%Training Data
        XTrain = mat2cell([data_fold1, data_fold2, data_fold3, data_fold5], 402, ones(1,276))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical([label_fold1; label_fold2; label_fold3; label_fold5]);

        elseif a == 5
		%Testing Data
        XTest = mat2cell(data_fold5, 402, ones(1,69))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(label_fold5);

		%Training Data
        XTrain = mat2cell([data_fold1, data_fold2, data_fold3, data_fold1], 402, ones(1,276))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical([label_fold1; label_fold2; label_fold3; label_fold1]);
        end


        %% DEFINE LSTM NETWORK ARCHITECTURE
        inputSize = 1;
        numHiddenUnits = b;
        numClasses = 2;
        miniBatchSize = d;
        
        layers = [ ...
            sequenceInputLayer(inputSize)
            bilstmLayer(numHiddenUnits,OutputMode="last")
            fullyConnectedLayer(numClasses) 
            softmaxLayer
            classificationLayer]
        
        options = trainingOptions("adam", ...
            ExecutionEnvironment="cpu", ...
            GradientThreshold=c, ...
            MaxEpochs=3, ...
            MiniBatchSize=miniBatchSize, ...
            SequenceLength="longest", ...
            Shuffle="never", ...
            Verbose=0, ...
            Plots="training-progress");
        %% TRAIN LSTM NETWORK
        net = trainNetwork(XTrain, YTrain, layers, options);
        
        %% TEST LSTM NETWORK
        numObservationsTest = numel(XTest);
        for i=1:numObservationsTest
            sequence = XTest{i};
            sequenceLengthsTest(i) = size(sequence,2);
        end
        
        [sequenceLengthsTest,idx] = sort(sequenceLengthsTest);
        XTest = XTest(idx);
        YTest = YTest(idx);
        
        YPred = classify(net,XTest, ...
            MiniBatchSize=miniBatchSize, ...
            SequenceLength="longest");

        accuracy(aa_model_num) = sum(YPred == YTest)./numel(YTest);
        delete(findall(0));
        fprintf('Model # %d, time = %f\n',aa_model_num,toc)
        result(:,aa_model_num) = YPred;
        end
    end
    end
end
save('accuracy_v5.mat','accuracy')
save('results_v5.mat','result')

%% Plotting Results
close all
figure()
plot(accuracy,'b.')
hold on
yline(mean(accuracy),'r');
title('LSTM: Cross Validation (n=2500)','Fontname','Times')
xlabel('Model Iteration','Fontname','Times')
ylabel('Model Accuracy in Testing Data','Fontname','Times')
legend('Individual Model Iteration','Average Model Accurary: 80.1%','Location','southeast','Fontname','Times')
set(gca,'Fontname','Times')
figure()

result_reshape = reshape(result,[6900,1]);
YTest_reshape = repmat(YTest,100,1);
plotconfusion(YTest_reshape,result_reshape)