%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course:     COMP 562  
% Instructor: Dr. Jorge Silva
% Assignment: Final Project   
%   
% Author:           Caleb Ryan Darr - crd.darr@gmail.
% Collaborators:    Austin L. M.
% 
% Description: 
% scripted used to analysis raw ground reaction force data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc;
%% LOAD DATA
% data = readmatrix('fullFeats.csv')'; % Raw Data
% data = readmatrix('backFeats_v3.csv')'; % Snipped Raw Data to area of interest
data = readmatrix('fullFeats_long.csv'); % Full Raw Data for snipped raw data
% labels = readmatrix('labelFileBinary_v3.csv'); % Labels of binary data for full raw data
labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data for full raw data
% labels = readmatrix('LabelFile.csv'); % Labels of 3 classes data



%% Plot Raw Data
normal = find(labels==1);
abnormal = find(labels==0);

figure(1)
%Subplot 1
sgtitle('Ground Reaction Time Series Normal vs Abnormal')
for i = normal
    subplot(2,2,1)
    plot(data(:,i))
    hold on
end
title('Normal')
xlabel('Time (t)')
ylabel('Ground Reaction Force (N)')
ylim([0 1250])
hold off

%Subplot 3
normal_avg = 0;
for i = 1:length(normal)
    normal_avg = normal_avg + data(:,normal(i));
end
normal_avg = normal_avg/length(normal);
subplot(2,2,3)
plot(normal_avg)
title('Normal Average')
xlabel('Time (t)')
ylabel('Ground Reaction Force (N)')
ylim([0 1250])
hold off

%Subplot 2
for i = abnormal
    subplot(2,2,2)
    plot(data(:,i))
    hold on
end
title('Abnormal')
xlabel('Time (t)')
ylabel('Ground Reaction Force (N)')
ylim([0 1250])
hold off

%Subplot 4
abnormal_avg = 0;
for i = 1:length(abnormal)
    abnormal_avg = abnormal_avg + data(:,abnormal(i));
end
abnormal_avg = abnormal_avg/length(abnormal);
subplot(2,2,4)
plot(abnormal_avg)
title('Abnormal Average')
xlabel('Time (t)')
ylabel('Ground Reaction Force (N)')
ylim([0 1250])
hold off

%% Frequency Domain of Time Data (single-sided amplitude spectrum)
Fs = 1000;    % Sampling Frequency
T = 1/Fs;   % Sampling period
L = size(data,1);   % Length of signal
t = (0:L-1)*T;      % Time vector

% Take fft of entire data sets
for i = 1:size(data,2)
Yn = fft(data(:,i));
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Yn/L);
dataFreq(:,i) = P2(1:(L+1)/2);
dataFreq(2:end,i) = 2*dataFreq(2:end,i);
end


Yn = fft(normal_avg);
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Yn/L);
P1 = P2(1:(L+1)/2);
P1(2:end) = 2*P1(2:end);

figure(2)
subplot(1,2,1)
plot(f,P1,"-o") 
title("Single-Sided Spectrum of Normal Signal")
xlabel("f (Hz)")
ylabel("|P1(f)|")
xlim([0 40])
Ya = fft(abnormal_avg);
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Ya/L);
P1 = P2(1:(L+1)/2);
P1(2:end) = 2*P1(2:end);

subplot(1,2,2)
plot(f,P1,"-o") 
title("Single-Sided Spectrum of Normal Signal")
xlabel("f (Hz)")
ylabel("|P1(f)|")
xlim([0 40])

%% Momentum of data
for i = 1:size(data,2)
dataM(:,i) = diff(data(:,i));
end

figure(1)
%Subplot 1
sgtitle('Ground Reaction Momentum Time Series Normal vs Abnormal')
for i = normal
    subplot(2,2,1)
    plot(dataM(:,i))
    hold on
end
title('Normal')
xlabel('Time (t)')
ylabel('Ground Reaction Momentum')
ylim([-20 60])
hold off

%Subplot 3
normal_avg = 0;
for i = 1:length(normal)
    normal_avg = normal_avg + dataM(:,normal(i));
end
normal_avg = normal_avg/length(normal);
subplot(2,2,3)
plot(normal_avg)
title('Normal Average')
xlabel('Time (t)')
ylabel('Ground Reaction Momentum')
ylim([-20 60])
hold off

%Subplot 2
for i = abnormal
    subplot(2,2,2)
    plot(dataM(:,i))
    hold on
end
title('Abnormal')
xlabel('Time (t)')
ylabel('Ground Reaction Momentum')
ylim([-20 60])
hold off

%Subplot 4
abnormal_avg = 0;
for i = 1:length(abnormal)
    abnormal_avg = abnormal_avg + dataM(:,abnormal(i));
end
abnormal_avg = abnormal_avg/length(abnormal);
subplot(2,2,4)
plot(abnormal_avg)
title('Abnormal Average')
xlabel('Time (t)')
ylabel('Ground Reaction Momentum')
ylim([-20 60])
hold off

%% Frequency Domain of Momentum (single-sided amplitude spectrum)
Fs = 1200;    % Sampling Frequency
T = 1/Fs;   % Sampling period
L = size(dataM,1);   % Length of signal
t = (0:L-1)*T;      % Time vector

% Take fft of entire data sets
for i = 1:size(dataM,2)
Yn = fft(dataM(:,i));
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Yn/L);
dataMFreq(:,i) = P2(1:(L+1)/2);
dataMFreq(2:end,i) = 2*dataMFreq(2:end,i);
end


Yn = fft(normal_avg);
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Yn/L);
P1 = P2(1:(L+1)/2);
P1(2:end) = 2*P1(2:end);

figure(2)
subplot(1,2,1)
plot(f,P1,"-o") 
title("Single-Sided Spectrum of Normal Signal")
xlabel("f (Hz)")
ylabel("|P1(f)|")
xlim([0 40])
Ya = fft(abnormal_avg);
f = Fs*(0:(L-1)/2)/L;
P2 = abs(Ya/L);
P1 = P2(1:(L+1)/2);
P1(2:end) = 2*P1(2:end);

subplot(1,2,2)
plot(f,P1,"-o") 
title("Single-Sided Spectrum of Normal Signal")
xlabel("f (Hz)")
ylabel("|P1(f)|")
xlim([0 40])

%% Save data
csvwrite('data_Force.csv',data)
csvwrite('data_ForceFreq.csv',dataFreq)
csvwrite('data_momentum.csv',dataM)
csvwrite('data_momentumFreq.csv',dataMFreq)