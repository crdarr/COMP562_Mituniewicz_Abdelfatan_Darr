%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Course:     COMP 562  
% Instructor: Dr. Jorge Silva
% Assignment: Final Project   
%   
% Author:           Caleb Ryan Darr - crd.darr@gmail.
% Collaborators:    Austin L. M.
% 
% Description: 
% Classifer for dangerous vs safe guage cycle ground reaction force time
% series using Long short-term memory (LSTM) network.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc;
%% LOAD DATA

% Full time data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('fullFeats_long.csv'); % Snipped Raw Data to area of interest

% Snipped time data
data = readmatrix('backFeats_v3.csv')'; % Snipped Raw Data to area of interest
labels = readmatrix('labelFileBinary_v3.csv'); % Labels of binary data

% Time frequency Data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('data_ForceFreq.csv'); % Snipped Raw Data to area of interest

% Momentum Data
% labels = readmatrix('labelFileBinary_long.csv'); % Labels of binary data
% data = readmatrix('data_momentum.csv'); % Snipped Raw Data to area of interest

%% HYPER PARAMETERS
miniBatch = 25;
HiddenUnits = 12;
train_vect = 0.7;

for a = miniBatch
    for b = HiddenUnits
        for c =  train_vect
        % TRAINING VS TESTING
        train = ceil(c*length(labels));    % Fraction of data to be deligated to training
        % Training Data
        XTrain = mat2cell(data(:,1:train), size(data(:,1:train),1), ones(1,train))';
        XTrain = cellfun(@transpose,XTrain,'UniformOutput',false);
        YTrain = categorical(labels(1:train));
    
        % Testing Data
        XTest = mat2cell(data(:,train+1:end), size(data(:,train+1:end),1), ones(1,length(labels)-train))';
        XTest = cellfun(@transpose,XTest,'UniformOutput',false);
        YTest = categorical(labels(train+1:end))

        %% DEFINE LSTM NETWORK ARCHITECTURE
        inputSize = 1;
        numHiddenUnits = b;
        numClasses = 2;
        miniBatchSize = a;
        
        layers = [ ...
            sequenceInputLayer(inputSize)
            bilstmLayer(numHiddenUnits,OutputMode="last")
            fullyConnectedLayer(numClasses) 
            softmaxLayer
            classificationLayer]
        
        options = trainingOptions("adam", ...
            ExecutionEnvironment="cpu", ...
            GradientThreshold=1, ...
            MaxEpochs=3, ...
            MiniBatchSize=miniBatchSize, ...
            SequenceLength="longest", ...
            Shuffle="never", ...
            Verbose=0, ...
            Plots="training-progress");
        %% TRAIN LSTM NETWORK
        net = trainNetwork(XTrain, YTrain, layers, options);
        
        %% TEST LSTM NETWORK
        numObservationsTest = numel(XTest);
        for i=1:numObservationsTest
            sequence = XTest{i};
            sequenceLengthsTest(i) = size(sequence,2);
        end
        
        [sequenceLengthsTest,idx] = sort(sequenceLengthsTest);
        XTest = XTest(idx);
        YTest = YTest(idx);
        
        YPred = classify(net,XTest, ...
            MiniBatchSize=miniBatchSize, ...
            SequenceLength="longest");

        accuracy = sum(YPred == YTest)./numel(YTest);
        acc(c*10) = accuracy;
        end
    end
end